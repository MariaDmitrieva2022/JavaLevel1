package lesson6;

public class hw6 {
    public static void main(String[] args) {
        Cat cat = new Cat();
        cat.run(300);
        cat.swim(50);

        Cat cat2 = new Cat();
        cat2.run(190);
        cat2.swim(30);

        Dog dog = new Dog();
        dog.run(600);
        dog.swim(20);

        Dog dog2 = new Dog();
        dog2.run(400);
        dog2.swim(9);
    }

}
