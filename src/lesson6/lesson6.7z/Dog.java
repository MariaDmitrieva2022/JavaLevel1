package lesson6;
public class Dog extends Animal {
    public Dog() {
        maxRunDistance = 500;
        maxSwimDistance = 10;
        name = "Пёс";
    }
}
